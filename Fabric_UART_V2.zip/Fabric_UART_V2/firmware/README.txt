Export Firmware README

Microsemi Corporation - Microsemi Libero Software Release v11.7 (Version 11.7.0.119)

Date    :    Mon Feb 06 11:48:56 2017
Project :    C:\Users\Hiperwall\Desktop\microsemilab\Fabric_UART_V2
