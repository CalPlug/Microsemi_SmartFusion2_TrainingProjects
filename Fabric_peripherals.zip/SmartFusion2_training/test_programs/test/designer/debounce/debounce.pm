[ALIST]
Alists=
[CONE]
Cones=
[DRCSettings]
DRCMode=Minimal
[FIND]
Finder=0 1 0 0 0 0 0 0 0 0 0 0 0
StringToFind=*
CellType=
PaneName=
[FRAME]
Tools=HYDRA_netlist_viewer 
ActiveTool=HYDRA_netlist_viewer
PropertyList=WindowPlacement 
WindowPlacement=0 1 -1 -1 -1 -1 198 198 1158 918
[HIGHLIGHT GROUPS]
CurrentGroup=0
NumGroups=15
[HighlightGroup0]
Name=HighlightGroup0
Color=166 0 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup1]
Name=HighlightGroup1
Color=0 255 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup2]
Name=HighlightGroup2
Color=0 255 255
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup3]
Name=HighlightGroup3
Color=212 208 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup4]
Name=HighlightGroup4
Color=0 0 255
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup5]
Name=HighlightGroup5
Color=255 255 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup6]
Name=HighlightGroup6
Color=0 0 128
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup7]
Name=HighlightGroup7
Color=0 128 128
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup8]
Name=HighlightGroup8
Color=0 128 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup9]
Name=HighlightGroup9
Color=128 0 128
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup10]
Name=HighlightGroup10
Color=128 0 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup11]
Name=HighlightGroup11
Color=128 128 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup12]
Name=HighlightGroup12
Color=128 128 128
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup13]
Name=HighlightGroup13
Color=212 192 192
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup14]
Name=HighlightGroup14
Color=0 0 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HIERARCHY VIEW]
DockState=0
PropertyList=WindowPlacement 
WindowPlacement=0 1 -1 -1 -1 -1 1 -2 201 429
ActiveTab=0
[LOG VIEW]
DockState=0
PropertyList=WindowPlacement 
WindowPlacement=0 1 -1 -1 -1 -1 241 5 944 155
[NETLIST VIEW]
NumWindow=1
[NETLIST VIEW1]
PropertyList=FIT LEVEL PAGE SPLIT ViewportExtents WindowPlacement 
FIT=0
LEVEL=AdlTop
PAGE=1
SPLIT=1
ViewportExtents=72798 58849 103202 72238
WindowPlacement=0 1 -1 -1 -1 -1 0 0 601 305
[SELECTION]
Macros=3,4,5,6,7,0
Nets=0
Regions=
Modules=-1 -1
Paths=
[WORLD VIEW]
DockState=0
PropertyList=WindowPlacement 
WindowPlacement=0 1 -1 -1 -1 -1 1 5 235 155
