/*=============================================================*/
/* Created by Microsemi SmartDesign Thu Feb 02 00:50:53 2017   */
/*                                                             */
/* Warning: Do not modify this file, it may lead to unexpected */
/*          functional failures in your design.                */
/*                                                             */
/*=============================================================*/

/*-------------------------------------------------------------*/
/* SERDESIF_0 Initialization                                   */
/*-------------------------------------------------------------*/

#define SERDES_0_CFG_NB_OF_PAIRS 3u

