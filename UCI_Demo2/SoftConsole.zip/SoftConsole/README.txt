Export Firmware README

Microsemi Corporation - Microsemi Libero Software Release v11.7 (Version 11.7.0.119)

Date    :    Tue Feb 07 10:01:38 2017
Project :    C:\Users\Hiperwall\Desktop\microsemilab\UCI_Demo2
